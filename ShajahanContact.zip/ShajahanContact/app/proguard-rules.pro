# Add project specific ProGuard rules here.
-keep class com.shajahan.contact.data.** { *; }
