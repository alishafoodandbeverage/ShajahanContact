package com.shajahan.contact.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val normalizedNumber: String = "", // for better matching
    val firebaseId: String = "" // document id in Firestore
)
