package com.shajahan.contact.data

import android.content.ContentResolver
import android.content.Context
import android.provider.ContactsContract
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ContactRepository(private val context: Context) {

    private val dao = ContactDatabase.getDatabase(context).contactDao()
    private val firestore = FirebaseFirestore.getInstance()
    private val collection = firestore.collection("shajahan_contacts")

    fun getAllContacts(): Flow<List<Contact>> = dao.getAllContacts()

    fun searchContacts(query: String): Flow<List<Contact>> {
        return if (query.isBlank()) {
            dao.getAllContacts()
        } else {
            dao.searchContacts(query.trim())
        }
    }

    suspend fun getCount(): Int = dao.getCount()

    /**
     * Import contacts from phone + sync to Firebase
     */
    suspend fun importFromPhoneAndSync(): Int {
        val phoneContacts = readPhoneContacts()
        if (phoneContacts.isEmpty()) return 0

        // Clear old local data
        dao.deleteAll()

        // Save to local + Firebase
        val contactsWithIds = mutableListOf<Contact>()
        for (c in phoneContacts) {
            val docId = UUID.randomUUID().toString()
            val contact = c.copy(firebaseId = docId)
            contactsWithIds.add(contact)

            // Upload to Firestore
            try {
                collection.document(docId).set(
                    mapOf(
                        "name" to contact.name,
                        "phoneNumber" to contact.phoneNumber,
                        "normalizedNumber" to contact.normalizedNumber
                    )
                ).await()
            } catch (e: Exception) {
                Log.e("ContactRepo", "Firebase upload failed: ${e.message}")
            }
        }

        dao.insertAll(contactsWithIds)
        return contactsWithIds.size
    }

    /**
     * If local is empty, try to download from Firebase (for new phone)
     */
    suspend fun restoreFromFirebaseIfNeeded(): Int {
        val localCount = dao.getCount()
        if (localCount > 0) return localCount

        return try {
            val snapshot = collection.get().await()
            val list = snapshot.documents.mapNotNull { doc ->
                val name = doc.getString("name") ?: return@mapNotNull null
                val phone = doc.getString("phoneNumber") ?: return@mapNotNull null
                val normalized = doc.getString("normalizedNumber") ?: normalizePhone(phone)
                Contact(
                    name = name,
                    phoneNumber = phone,
                    normalizedNumber = normalized,
                    firebaseId = doc.id
                )
            }
            if (list.isNotEmpty()) {
                dao.insertAll(list)
            }
            list.size
        } catch (e: Exception) {
            Log.e("ContactRepo", "Firebase restore failed: ${e.message}")
            0
        }
    }

    private fun readPhoneContacts(): List<Contact> {
        val list = mutableListOf<Contact>()
        val resolver: ContentResolver = context.contentResolver

        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
        )

        cursor?.use {
            val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

            val seen = mutableSetOf<String>() // avoid duplicates

            while (it.moveToNext()) {
                val name = it.getString(nameIdx)?.trim() ?: continue
                var number = it.getString(numberIdx)?.trim() ?: continue
                number = number.replace(" ", "").replace("-", "")

                val key = "$name|$number"
                if (seen.contains(key)) continue
                seen.add(key)

                if (name.isNotBlank() && number.isNotBlank()) {
                    list.add(
                        Contact(
                            name = name,
                            phoneNumber = number,
                            normalizedNumber = normalizePhone(number)
                        )
                    )
                }
            }
        }
        return list
    }

    private fun normalizePhone(phone: String): String {
        // Keep only digits, handle +880 / 880 / 0
        var digits = phone.filter { it.isDigit() }
        if (digits.startsWith("880") && digits.length > 10) {
            digits = "0" + digits.substring(3)
        }
        return digits
    }

    /**
     * Update a contact (local + Firebase)
     */
    suspend fun updateContact(contact: Contact) {
        val updated = contact.copy(
            normalizedNumber = normalizePhone(contact.phoneNumber)
        )
        dao.update(updated)

        if (updated.firebaseId.isNotBlank()) {
            try {
                collection.document(updated.firebaseId).set(
                    mapOf(
                        "name" to updated.name,
                        "phoneNumber" to updated.phoneNumber,
                        "normalizedNumber" to updated.normalizedNumber
                    )
                ).await()
            } catch (e: Exception) {
                Log.e("ContactRepo", "Firebase update failed: ${e.message}")
            }
        }
    }

    /**
     * Delete a contact (local + Firebase)
     */
    suspend fun clearAll() {
        val all = dao.getAllOnce()
        for (c in all) {
            if (c.firebaseId.isNotBlank()) {
                try { collection.document(c.firebaseId).delete().await() } catch (_: Exception) {}
            }
        }
        dao.deleteAll()
    }

    suspend fun deleteContact(contact: Contact) {
        dao.delete(contact)

        if (contact.firebaseId.isNotBlank()) {
            try {
                collection.document(contact.firebaseId).delete().await()
            } catch (e: Exception) {
                Log.e("ContactRepo", "Firebase delete failed: ${e.message}")
            }
        }
    }
}
