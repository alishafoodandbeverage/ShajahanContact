# Shajahan Contact - বাবার জন্য কন্টাক্ট অ্যাপ

## অ্যাপের কাজ

- ফোনের সব কন্টাক্ট ইমপোর্ট করে
- Firebase-এ ব্যাকআপ রাখে (মোবাইল চেঞ্জ করলেও ডাটা থাকে)
- বড় ফন্ট + উচ্চ কনট্রাস্ট (বয়স্ক চোখের জন্য)
- সার্চ বার (বাংলা/ইংরেজি দুটোতেই কাজ করে)
- মাইক্রোফোন দিয়ে ভয়েস সার্চ
- প্রতিটি কন্টাক্টে: **কল**, **WhatsApp**, **IMO** বাটন
- প্রতিবার খোলার পর স্বাগতিক বাংলা ভয়েসে স্বাগতম বার্তা

---

## Android Studio দিয়ে APK বানানোর ধাপ (একদম ফ্রি)

### ১. Android Studio ইন্সটল করুন
- লিংক: https://developer.android.com/studio
- ডাউনলোড করে ইন্সটল করুন (Windows/Mac/Linux সব সাপোর্ট করে)

### ২. প্রজেক্ট ওপেন করুন
1. Android Studio খুলুন
2. **Open** বাটনে ক্লিক করুন
3. এই ফোল্ডারটি সিলেক্ট করুন: `ShajahanContact`
4. প্রথমবার অনেকক্ষণ লাগতে পারে (Gradle download)

### ৩. APK তৈরি করুন

#### সহজ উপায় (Debug APK - টেস্টিংয়ের জন্য):
1. উপরের মেনু → **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
2. কিছুক্ষণ পর নিচে নোটিফিকেশন আসবে
3. **locate** ক্লিক করলে APK পাবেন  
   লোকেশন সাধারণত: `app/build/outputs/apk/debug/app-debug.apk`

#### রিলিজ APK (বাবাকে দেওয়ার জন্য ভালো):
1. **Build** → **Generate Signed Bundle / APK**
2. **APK** সিলেক্ট করে Next
3. **Create new...** ক্লিক করে Keystore তৈরি করুন:
   - Key store path: যেকোনো জায়গায় সেভ করুন
   - Password দিন (মনে রাখবেন)
   - Alias: shajahan
   - Validity: 25 years
4. Next → **release** সিলেক্ট করুন → Finish
5. APK তৈরি হলে `app/build/outputs/apk/release/` ফোল্ডারে পাবেন

### ৪. বাবার ফোনে ইন্সটল
- APK ফাইলটি WhatsApp/USB দিয়ে পাঠান
- ফোনে **Unknown sources** থেকে ইন্সটল করার অনুমতি দিন
- ইন্সটল করার পর অ্যাপ খুললে কন্টাক্ট ও মাইক পারমিশন দিতে বলবে → **Allow** দিন

---

## গুরুত্বপূর্ণ নোট

- প্রথমবার ইন্টারনেট লাগবে (Firebase + Google TTS/Speech)
- বাংলা ভয়েস ভালো পেতে Google Text-to-Speech অ্যাপ আপডেট রাখুন
- WhatsApp ও IMO ইন্সটল থাকা ভালো
- মোবাইল চেঞ্জ করলে নতুন ফোনে অ্যাপ ইন্সটল করে একই পারমিশন দিলে Firebase থেকে কন্টাক্ট চলে আসবে

---

## Package Name
`com.shajahan.contact`
